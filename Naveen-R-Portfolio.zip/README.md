# Naveen R — Portfolio

A deploy-ready static portfolio for Naveen R.

## Deploy on Vercel
1. Go to https://vercel.com/new
2. Choose **Import Third-Party / Deploy without Git** (or drag-and-drop the project folder if available).
3. Upload this folder.
4. Vercel will provide a live `.vercel.app` URL.

No build command or framework is required.

## Customize
- Replace `assets/naveen.png` with your preferred portrait if needed.
- Add your resume as `assets/Naveen-Resume.pdf`.
- Update the resume button in `index.html` to point to `assets/Naveen-Resume.pdf`.
- Add the Restaurant Management GitHub URL when the repository is available.
